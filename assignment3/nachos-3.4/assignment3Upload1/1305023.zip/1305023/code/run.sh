make
cd test
make
cd ../userprog/
make
cd ..
make
cd ./userprog/
echo ""
echo "code made"
echo ""
./nachos -x ../test/$1