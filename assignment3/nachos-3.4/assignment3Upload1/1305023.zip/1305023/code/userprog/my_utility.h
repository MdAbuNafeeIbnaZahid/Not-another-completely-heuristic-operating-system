#ifndef MY_UTILITY_H
#define MY_UTILITY_H

int myMin(int a, int b)
{
	int ret = a<b?a:b;
	return ret;
}


#endif