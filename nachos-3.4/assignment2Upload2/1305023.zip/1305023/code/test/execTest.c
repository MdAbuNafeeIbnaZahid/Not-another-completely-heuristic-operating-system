#include "syscall.h"

int
main()
{
	Exec("../test/codeDataTest");
    Halt();
    /* not reached */
}
