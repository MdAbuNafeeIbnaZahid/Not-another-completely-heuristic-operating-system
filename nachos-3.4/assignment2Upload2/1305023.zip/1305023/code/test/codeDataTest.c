
int ar[5];
int i, j, k;
char str[19];

int main()
{
	/* code */
	Read(str, 10, 0);
	
	Write("\n", 1, 0);

	Write(str, 5, 0);
	
	// for (i = 0; i < 5; i++)
	// {
	// 	ar[i] = i;
	// }
	
	Exit(0);
}